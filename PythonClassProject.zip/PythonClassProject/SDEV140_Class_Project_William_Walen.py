## Program must be ran with Administrator permissions for it to read the temperature data

## In this section we are importing the modules and resources we need to run the program
import clr # the pythonnet module

clr.AddReference(r'\DLLs\OpenHardwareMonitorLib')
from tkinter import *

from OpenHardwareMonitor.Hardware import Computer

c = Computer()
## Getting the Info about CPU
c.CPUEnabled = True
## Getting the Info about GPU
c.GPUEnabled = True

c.Open()
## This section I'm opening a window and naming it
window = Tk()

window.title("CPU Monitor")

## The next section is the function that displays the temperature readouts for the cpu and gpu

def cpuRead():

        for a in range(0, len(c.Hardware[0].Sensors)):

            if "/temperature/1" in str(c.Hardware[0].Sensors[a].Identifier):

                cpu_temp = c.Hardware[0].Sensors[a].get_Value()

                cpu_core_1_C["text"]=str(cpu_temp)

                cpu_tempF = (cpu_temp * 9/5) + 32

                cpu_core_1_F["text"]=str(cpu_tempF)

                c.Hardware[0].Update()

            if "/temperature/2" in str(c.Hardware[0].Sensors[a].Identifier):

                cpu_temp = c.Hardware[0].Sensors[a].get_Value()

                cpu_core_2_C["text"]=str(cpu_temp)

                c.Hardware[0].Update()

                cpu_tempF = (cpu_temp * 9/5) + 32

                cpu_core_2_F["text"]=str(cpu_tempF)

            if "/temperature/3" in str(c.Hardware[0].Sensors[a].Identifier):

                cpu_temp = c.Hardware[0].Sensors[a].get_Value()

                cpu_core_3_C["text"]=str(cpu_temp)

                c.Hardware[0].Update()

                cpu_tempF = (cpu_temp * 9/5) + 32

                cpu_core_3_F["text"]=str(cpu_tempF)

            if "/temperature/4" in str(c.Hardware[0].Sensors[a].Identifier):

                cpu_temp = c.Hardware[0].Sensors[a].get_Value()

                cpu_core_4_C["text"]=str(cpu_temp)

                c.Hardware[0].Update()

                cpu_tempF = (cpu_temp * 9/5) + 32

                cpu_core_4_F["text"]=str(cpu_tempF)

            if "/temperature/5" in str(c.Hardware[0].Sensors[a].Identifier):

                cpu_temp = c.Hardware[0].Sensors[a].get_Value()

                cpu_core_5_C["text"]=str(cpu_temp)

                c.Hardware[0].Update()

                cpu_tempF = (cpu_temp * 9/5) + 32

                cpu_core_5_F["text"]=str(cpu_tempF)

            if "/temperature/6" in str(c.Hardware[0].Sensors[a].Identifier):

                cpu_temp = c.Hardware[0].Sensors[a].get_Value()

                cpu_core_6_C["text"]=str(cpu_temp)

                c.Hardware[0].Update()

                cpu_tempF = (cpu_temp * 9/5) + 32

                cpu_core_6_F["text"]=str(cpu_tempF)

            if "/temperature/7" in str(c.Hardware[0].Sensors[a].Identifier):

                cpu_temp = c.Hardware[0].Sensors[a].get_Value()

                cpu_core_7_C["text"]=str(cpu_temp)

                c.Hardware[0].Update()

                cpu_tempF = (cpu_temp * 9/5) + 32

                cpu_core_7_F["text"]=str(cpu_tempF)

            if "/temperature/8" in str(c.Hardware[0].Sensors[a].Identifier):

                cpu_temp = c.Hardware[0].Sensors[a].get_Value()

                cpu_core_8_C["text"]=str(cpu_temp)

                c.Hardware[0].Update()

                cpu_tempF = (cpu_temp * 9/5) + 32

                cpu_core_8_F["text"]=str(cpu_tempF)

        for a in range(0, len(c.Hardware[1].Sensors)):

            if "/temperature/0" in str(c.Hardware[1].Sensors[a].Identifier):

                gpu_temp = c.Hardware[1].Sensors[a].get_Value()

                gpu_core_C["text"]=str(gpu_temp)

                c.Hardware[1].Update()

                gpu_tempF = (gpu_temp * 9/5) + 32

                gpu_core_F["text"]=str(gpu_tempF)


## This section lists the variables that each button and label is assigned to

start_cpu = Button(window, text="Start", command=cpuRead)

celsius = Label(window, text="Celsius")

fahren = Label(window, text="Fahren")

cpu_core_1 = Label(window,text="Core 1:")

cpu_core_2 = Label(window,text="Core 2:")

cpu_core_3 = Label(window,text="Core 3:")

cpu_core_4 = Label(window,text="Core 4:")

cpu_core_5 = Label(window,text="Core 5:")

cpu_core_6 = Label(window,text="Core 6:")

cpu_core_7 = Label(window,text="Core 7:")

cpu_core_8 = Label(window,text="Core 8:")

gpucore = Label(window,text="GPU:")

cpu_core_1_C = Label(window,text="00.0")

cpu_core_2_C = Label(window,text="00.0")

cpu_core_3_C = Label(window,text="00.0")

cpu_core_4_C = Label(window,text="00.0")

cpu_core_5_C = Label(window,text="00.0")

cpu_core_6_C = Label(window,text="00.0")

cpu_core_7_C = Label(window,text="00.0")

cpu_core_8_C = Label(window,text="00.0")

gpu_core_C = Label(window,text="00.0")

cpu_core_1_F = Label(window,text="00.0")

cpu_core_2_F = Label(window,text="00.0")

cpu_core_3_F = Label(window,text="00.0")

cpu_core_4_F = Label(window,text="00.0")

cpu_core_5_F = Label(window,text="00.0")

cpu_core_6_F = Label(window,text="00.0")

cpu_core_7_F = Label(window,text="00.0")

cpu_core_8_F = Label(window,text="00.0")

gpu_core_F = Label(window,text="00.0")


## This section sets up the grid pattern for the GUI
start_cpu.grid(row=0,column=0)

celsius.grid(row=0,column=1)

fahren.grid(row=0,column=2)

cpu_core_1.grid(row=1,column=0)

cpu_core_1_C.grid(row=1,column=1)

cpu_core_1_F.grid(row=1,column=2)

cpu_core_2.grid(row=2,column=0)

cpu_core_2_C.grid(row=2,column=1)

cpu_core_2_F.grid(row=2,column=2)

cpu_core_3.grid(row=3,column=0)

cpu_core_3_C.grid(row=3,column=1)

cpu_core_3_F.grid(row=3,column=2)

cpu_core_4.grid(row=4,column=0)

cpu_core_4_C.grid(row=4,column=1)

cpu_core_4_F.grid(row=4,column=2)

cpu_core_5.grid(row=5,column=0)

cpu_core_5_C.grid(row=5,column=1)

cpu_core_5_F.grid(row=5,column=2)

cpu_core_6.grid(row=6,column=0)

cpu_core_6_C.grid(row=6,column=1)

cpu_core_6_F.grid(row=6,column=2)

cpu_core_7.grid(row=7,column=0)

cpu_core_7_C.grid(row=7,column=1)

cpu_core_7_F.grid(row=7,column=2)

cpu_core_8.grid(row=8,column=0)

cpu_core_8_C.grid(row=8,column=1)

cpu_core_8_F.grid(row=8,column=2)

gpucore.grid(row=10,column=0)

gpu_core_C.grid(row=10,column=1)

gpu_core_F.grid(row=10,column=2)

window.mainloop()